$(document).ready(function() {
	adminicaUi();
});

$(window).load(function(){
	adminicaInit();
});