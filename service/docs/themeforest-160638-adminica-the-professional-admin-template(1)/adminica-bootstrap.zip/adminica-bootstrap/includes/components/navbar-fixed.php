<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container-fluid">
      <button type="button"class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="brand" href="#" style="">Adminica Bootstrap</a>
      <ul class="nav pull-right">
        <li class="active dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Adminica <b class="caret"></b></a>
			    <ul class="dropdown-menu">
			      <li><a target="_blank" href="http://templates.tricyclelabs.com/adminica/">Regular Version</a></li>
			      <li><a target="_blank" href="http://templates.tricyclelabs.com/adminica-bootstrap/">Bootstrap Version</a></li>
			      <li class="divider"></li>
			      <li><a target="_blank" href="http://themeforest.net/item/adminica-the-professional-admin-template/160638">Product Page</a></li>
			    </ul>
        </li>
        <li class="divider-vertical"></li>
        <li>
          <a target="_blank" href="http://twitter.github.com/bootstrap/">Documentation</a>
        </li>
        <li class="divider-vertical"></li>
        <li>
          <a href="login.php">Logout</a>
        </li>
      </ul>
     </div>
  </div>
</div>