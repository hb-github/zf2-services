<div class="navbar">
	<div class="navbar-inner">
	  <div class="container-fluid">
		  <ul class="nav">
        <li class="">
          <a href="./index.html">Home</a>
        </li>
        <li class="divider-vertical"></li>
        <li class="">
          <a href="typography.php">Typography</a>
        </li>
        <li class="divider-vertical"></li>
        <li>
          <a href="layout.php">Layout</a>
        </li>
        <li class="divider-vertical"></li>
        <li class="">
          <a href="#">Forms</a>
        </li>
        <li class="divider-vertical"></li>
        <li class="">
          <a href="#">Tables</a>
        </li>
        <li class="divider-vertical"></li>
        <li class="">
          <a href="#">Components</a>
        </li>
        <li class="divider-vertical"></li>
        <li class="">
          <a href="#">Plugins</a>
        </li>
        <li class="divider-vertical"></li>
        <li class="">
          <a href="#">Logout</a>
        </li>
      </ul>
	  </div>
	</div>
</div>