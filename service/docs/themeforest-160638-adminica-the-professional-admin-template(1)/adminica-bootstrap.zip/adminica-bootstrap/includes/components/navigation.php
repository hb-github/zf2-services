<div id="nav_top" class="dropdown_menu clearfix round_top">
	<ul class="clearfix">
		<li><a href="layout.php"><img src="images/icons/small/grey/laptop.png"/><span>Home</span></a></li>
		<li><a href="layout.php"><img src="images/icons/small/grey/frames.png"/><span>Layout</span></a></li>
		<li><a href="#"><img src="images/icons/small/grey/list.png"/><span>Base</span></a>
			<ul>
				<li><a href="typography.php"><span>Typography</span></a></li>
				<li><a href="tables.php"><span>Tables</span></a></li>
				<li><a href="forms.php"><span>Forms</span></a></li>
				<li><a href="buttons.php"><span>Buttons</span></a></li>
				<li><a href="icons.php"><span>Icons</span></a></li>
			</ul>
		</li>
		<li><a target="_blank" href="http://twitter.github.com/bootstrap/components.html"><img src="images/icons/small/grey/blocks_images.png"/><span>Components</span></a></li>
		<li><a target="_blank" href="http://twitter.github.com/bootstrap/javascript.html"><img src="images/icons/small/grey/coverflow.png"/><span>Plugins</span></a></li>
	</ul>

	<div id="mobile_nav">
		<div class="main"></div>
		<div class="side"></div>
	</div>

</div><!-- #nav_top -->
