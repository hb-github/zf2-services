<ul class="gallery media_tiles clearfix" style="padding: 15px 0 5px 14px;">

	<li class="blue">
		<a href="#">
		<img src="images/profile.jpg" height="60" width="60" />
			<h3>Name Surname</h3>
			<p>$XXX.XX</p>
		</a>
	</li>
	<li class="blue">
		<a href="#">
		<img src="images/profile.jpg" height="60" width="60" />
			<h3>Name Surname</h3>
			<p>$XXX.XX</p>
		</a>
	</li>
	<li class="blue">
		<a href="#">
		<img src="images/profile.jpg" height="60" width="60" />
			<h3>Name Surname</h3>
			<p>$XXX.XX</p>
		</a>
	</li>
	<li class="blue">
		<a href="#">
		<img src="images/profile.jpg" height="60" width="60" />
			<h3>Name Surname</h3>
			<p>$XXX.XX</p>
		</a>
	</li>
	<li class="blue">
		<a href="#">
		<img src="images/profile.jpg" height="60" width="60" />
			<h3>Name Surname</h3>
			<p>$XXX.XX</p>
		</a>
	</li>

</ul>