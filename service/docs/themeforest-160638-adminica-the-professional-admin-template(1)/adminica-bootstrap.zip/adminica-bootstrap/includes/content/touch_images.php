<ul class="gallery clearfix" style="padding: 15px 0 5px 14px;">
	
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image01.jpg">
		<img src="images/profile.jpg" height="60" width="60"/>
		</a>
	</li>
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image01.jpg">
		<img src="images/profile.jpg" height="60" width="60"/>
		</a>
	</li>
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image01.jpg">
		<img src="images/profile.jpg" height="60" width="60"/>
		</a>
	</li>
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image01.jpg">
		<img src="images/profile.jpg" height="60" width="60"/>
		</a>
	</li>
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image01.jpg">
		<img src="images/profile.jpg" height="60" width="60"/>
		</a>
	</li>
			
</ul>