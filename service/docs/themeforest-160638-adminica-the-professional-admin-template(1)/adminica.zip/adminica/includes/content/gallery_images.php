<ul class="gallery fancybox delete_buttons clearfix">

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image01.jpg">
		<img src="images/content/gallery/blue/image01_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 1</span>
		<span class="size sort_2">71234kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image2.jpg">
		<img src="images/content/gallery/blue/image02_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 2</span>
		<span class="size sort_2">7235kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image3.jpg"
		><img src="images/content/gallery/blue/image03_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 3</span>
		<span class="size sort_2">1456kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image04.jpg">
		<img src="images/content/gallery/blue/image04_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 4</span>
		<span class="size sort_2">45671kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image05.jpg">
		<img src="images/content/gallery/blue/image05_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 5</span>
		<span class="size sort_2">15678kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image06.jpg">
		<img src="images/content/gallery/blue/image06_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 6</span>
		<span class="size sort_2">16678kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image07.jpg">
		<img src="images/content/gallery/blue/image07_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 7</span>
		<span class="size sort_2">17678kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image08.jpg">
		<img src="images/content/gallery/blue/image08_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 8</span>
		<span class="size sort_2">19678kb</span></a></li>

	<li class="blue">
		<a rel="collection" class="no_loading" href="images/content/gallery/blue/image09.jpg">
		<img src="images/content/gallery/blue/image09_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Blue 9</span>
		<span class="size sort_2">110678kb</span></a></li>

<!-- BW Images -->

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image01.jpg">
		<img src="images/content/gallery/grey/image01_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 1</span>
		<span class="size sort_2">234kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image02.jpg">
		<img src="images/content/gallery/grey/image02_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 2</span>
		<span class="size sort_2">2345kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image03.jpg"
		><img src="images/content/gallery/grey/image03_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 3</span>
		<span class="size sort_2">23456kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image04.jpg">
		<img src="images/content/gallery/grey/image04_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 4</span>
		<span class="size sort_2">456677kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image05.jpg">
		<img src="images/content/gallery/grey/image05_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 5</span>
		<span class="size sort_2">5678kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image06.jpg">
		<img src="images/content/gallery/grey/image06_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 6</span>
		<span class="size sort_2">678kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image07.jpg">
		<img src="images/content/gallery/grey/image07_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 7</span>
		<span class="size sort_2">7678kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image08.jpg">
		<img src="images/content/gallery/grey/image08_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 8</span>
		<span class="size sort_2">1978kb</span></a></li>

	<li class="bw">
		<a rel="collection" class="no_loading" href="images/content/gallery/grey/image09.jpg">
		<img src="images/content/gallery/grey/image09_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Grey 9</span>
		<span class="size sort_2">1108kb</span></a></li>

<!-- Sepia Images -->

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image01.jpg">
		<img src="images/content/gallery/sepia/image01_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 1</span>
		<span class="size sort_2">71234kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image02.jpg">
		<img src="images/content/gallery/sepia/image02_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 2</span>
		<span class="size sort_2">2345kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image03.jpg"
		><img src="images/content/gallery/sepia/image03_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 3</span>
		<span class="size sort_2">3456kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image04.jpg">
		<img src="images/content/gallery/sepia/image04_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 4</span>
		<span class="size sort_2">4567kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image05.jpg">
		<img src="images/content/gallery/sepia/image05_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 5</span>
		<span class="size sort_2">15678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image06.jpg">
		<img src="images/content/gallery/sepia/image06_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 6</span>
		<span class="size sort_2">16678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image07.jpg">
		<img src="images/content/gallery/sepia/image07_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 7</span>
		<span class="size sort_2">17678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image08.jpg">
		<img src="images/content/gallery/sepia/image08_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 8</span>
		<span class="size sort_2">19678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" class="no_loading" href="images/content/gallery/sepia/image09.jpg">
		<img src="images/content/gallery/sepia/image09_thumb.jpg" height="84" width="148"/>
		<span class="name sort_1">Sepia 9</span>
		<span class="size sort_2">110678kb</span></a></li>


</ul>