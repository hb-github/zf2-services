<label>Dynamic Loading:</label>
<div class="jqui_checkbox" id="pjax_switch">
	<input type="radio" name="dynamic_switch" id="dynamic_on"/><label for="dynamic_on">On</label>
	<input type="radio" name="dynamic_switch" id="dynamic_off" checked="checked"/><label for="dynamic_off">Off</label>
</div>