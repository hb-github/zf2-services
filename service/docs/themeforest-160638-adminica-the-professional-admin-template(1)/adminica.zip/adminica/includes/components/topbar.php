<div id="topbar" class="clearfix">

	<a href="dashboard_sorter.php" class="logo"><span>Adminica</span></a>

	<div class="user_box dark_box clearfix">
		<img src="images/interface/profile.jpg" width="55" alt="Profile Pic" />
		<h2>Administrator</h2>
		<h3><a class="text_shadow" href="#">John Smith</a></h3>
		<ul>
			<li><a href="#">profile</a><span class="divider">|</span></li>
			<li><a href="#">settings</a><span class="divider">|</span></li>
			<li><a href="login_slide.php" class="dialog_button" data-dialog="dialog_logout">Logout</a></li>
		</ul>
	</div><!-- #user_box -->
</div><!-- #topbar -->