<div id="stackbar" class="stackbar">	<div class="user_box dark_box clearfix">
		<img src="images/interface/profile.jpg" width="55" alt="Profile Pic" />
		<h2>Administrator</h2>
		<h3><a href="#">John Smith</a></h3>
		<ul>
			<li><a href="#">settings</a><span class="divider">|</span></li>
			<li><a href="login_slide.php" class="dialog_button" data-dialog="dialog_logout">Logout</a></li>
		</ul>
	</div>
	<ul class="">
		<li>
			<a href="#"><img src="images/icons/large/grey/computer_imac.png"/><span>Dashboard</span></a>
			<ul>
				<li><a href="index.php" class="pjax">Dashboard</a></li>
				<li><a href="layout.php" class="pjax">Layout</a></li>
				<li><a href="text.php" class="pjax">Typography</a></li>
				<li><a href="isolated_wizard.php" class="pjax">Isolated</a></li>
				<li><a href="logout_button.php" class="pjax">Logout</a></li>
			</ul>
		</li>
		<li>
			<a href="#"><img src="images/icons/large/grey/mail.png"/><span>Widgets</span><div class="alert badge alert_green">1</div></a>
			<ul>
				<li><a href="#">Widgets</a></li>
				<li><a href="tabs.php" class="pjax">Tabs</a></li>
				<li><a href="accordions.php" class="pjax">Accordions</a></li>
				<li><a href="wizard.php" class="pjax">Wizard</a></li>
				<li><a href="code.php" class="pjax">Code View</a></li>
				<li><a href="editor.php" class="pjax">Text Editor</a></li>
				<li><a href="dialog.php" class="pjax">Dialogs</a></li>
			</ul>
		</li>
		<li>
			<a href="#"><img src="images/icons/large/grey/users.png"/><span>Contacts</span><div class="alert badge alert_blue">2</div></a>
			<ul>
				<li><a href="#">Contacts</a></li>
				<li><a href="contacts.php" class="pjax">Profiles</a></li>
				<li><a href="contacts.php" class="pjax">Manage</a></li>
				<li><a href="#" class="dialog_button" data-dialog="dialog_register">Add</a></li>
			</ul>
		</li>
		<li>
			<a href="#"><img src="images/icons/large/grey/graph.png"/><span>Reports</span></a>
			<ul>
				<li><a href="#" class="pjax">Reports</a></li>
				<li><a href="charts.php" class="pjax">Graphs</a></li>
				<li><a href="graphs.php" class="pjax">Charts</a></li>
			</ul>
		</li>
	</ul>

